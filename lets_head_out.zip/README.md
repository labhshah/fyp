# lets_head_out

A flutter UI Challenge for Traveling

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)


## Screenshots


<p float="left">
  <img src="/screenshots/Screenshot_20200309-001321.png" width="200" />
  <img src="/screenshots/Screenshot_20200309-001328.png" width="200" /> 
  <img src="/screenshots/Screenshot_20200309-001340.png" width="200" />
   <img src="/screenshots/Screenshot_20200309-001347.png" width="200" />
   <img src="/screenshots/Screenshot_20200309-001404.png" width="200" />
  <img src="/screenshots/Screenshot_20200308-172505.png" width="200" />
  <img src="/screenshots/Screenshot_20200308-172514.png" width="200" />
  <img src="/screenshots/Screenshot_20200309-010933.png" width="200" />
   <img src="/screenshots/Screenshot_20200309-001409.png" width="200" />
     <img src="/screenshots/Screenshot_20200309-001409.png" width="200" />

   <img src="/screenshots/Screenshot_20200309-001419.png" width="200" />

   <img src="/screenshots/Screenshot_20200309-001443.png" width="200" />

   <img src="/screenshots/Screenshot_20200309-001448.png" width="200" />

   <img src="/screenshots/Screenshot_20200309-001457.png" width="200" />
   <img src="/screenshots/Screenshot_20200309-001505.png" width="200" />
      <img src="/screenshots/Screenshot_20200309-001511.png" width="200" />


</p>
