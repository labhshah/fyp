import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:lets_head_out/utils/BestRatedImage.dart';
import 'package:lets_head_out/utils/Buttons.dart';
import 'package:lets_head_out/utils/CitiesImage.dart';
import 'package:lets_head_out/utils/RecommendationImage.dart';
import 'package:lets_head_out/utils/TextStyles.dart';
import 'package:lets_head_out/utils/booking.dart';
import 'package:lets_head_out/utils/consts.dart';
import 'package:lets_head_out/utils/imageContainer.dart';

import 'OverViewScreen.dart';

class Dashboard extends StatefulWidget {
  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            ImageContainer(),

            Padding(
              padding: const EdgeInsets.only(left:16.0,right: 5.0,bottom: 16.0,top:16),

              child: Column(children: <Widget>[

                _dailyOfferText(),

                _hotelsListWidget(),

                _recommendedText(),
                
                _recommendedList(),

                Padding(
                  padding: const EdgeInsets.only( top: 10,bottom: 16.0),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: BoldText("Best Rated Places", 20.0, kblack)),
                ),

                _bestRatedList(),

                 
                Padding(
                  padding: const EdgeInsets.only(top: 10,bottom: 0.0),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: BoldText("Awesome Cities", 20.0, kblack)),
                ),

                _awesomeCitiesList(),
               

              ]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _awesomeCitiesList(){
    return Container(
        height: 450,
        child: Center(
          child: GridView(
            primary: false,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2,),
            shrinkWrap: false,
            children: [
              CitiesImage("assets/pokhara.jpg","Pokhara"),
              CitiesImage("assets/kathmandu.jpg","Kathmandu"),
              CitiesImage("assets/bhaktapur.jpg","Bhaktapur"),
              CitiesImage("assets/dharan.jpg","Dharan"),
  

            ],
          ),
        ),
      );
  }


  Widget _bestRatedList(){
    return Container(
      width: 400,
      height: 250,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: <Widget>[
          BestRatedImage("assets/kathmandu.jpg", "Kathmandu", "Nepal", 4.5),
          BestRatedImage("assets/pokhara.jpg", "Pokhara", "Nepal", 4.8),
          BestRatedImage("assets/biratnagar.jpg", "Biratnagar", "Nepal", 3.1),
        ],
      ),
    );
}


Widget _dailyOfferText(){
  return  Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Align(
          alignment: Alignment.centerLeft,
          child: BoldText("Daily Offers", 20.0, kblack)),
    );
}


Widget _recommendedText(){
  return Padding(
    padding: const EdgeInsets.only(top: 20),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        BoldText("Recommended for you", 20.0, kblack),
        Row(
          children: [
            BoldText("More", 15.0, korange),
            Icon(
              Icons.navigate_next,
              color: korange,
            ),
          ],
        )
      ],
    ),
  );
}

 Widget _recommendedList(){
   return Container(
      width: 400,
      height: 200,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: <Widget>[
          RecommendationImage("assets/annapurna.jpg", "Annapurna", "Kathmandu"),
          RecommendationImage("assets/shaara.jpg", "Shaara", "Pokhara"),
          RecommendationImage("assets/harrison.jpg", "Harrison Palace", "Biratnagar"),
        ],
      ),
    );
 }

  Row imagesRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        SquaredIcon(Icons.airplanemode_active, "Flights"),
        SquaredIcon(FontAwesomeIcons.hotel, "Hotels"),
        SquaredIcon(Icons.directions_car, "Cars"),
      ],
    );
  }

  Widget _hotelsListWidget(){
    return Container(
        width: double.infinity,
        height: 170,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: hotelList.length,
          itemBuilder: (context,i){
            return GestureDetector(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (_) {
              return OverViewPage(hotelList:hotelList[i]);
            }));
          },
              child: Container(
                margin: const EdgeInsets.only(right:20,top: 5,bottom: 5,left: 5),
                width: 320,
                height: 170,
                decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(10)),color: Colors.white,
                boxShadow: [BoxShadow(color: kdarkBlue.withOpacity(0.2),blurRadius: 4,offset: const Offset(2,2))]),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: 150,
                      height: 170,
                      child: ClipRRect(
                          borderRadius: new BorderRadius.only(
                              topLeft: Radius.circular(15),
                              bottomLeft: Radius.circular(15)),
                          child: Image.asset(
                      "assets/"+hotelList[i].imageUrl,
                      fit: BoxFit.fitHeight,
                    )),
                    ),
                    SizedBox(
                      width: 10.0,
                    ),
                  Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        BoldText(hotelList[i].hotelName, 20.5, kblack),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            BoldText("5 Stars", 15.0, korangelite),
                            Icon(
                              Icons.location_on,
                              color: kgreyDark,
                              size: 15.0,
                            ),
                            NormalText(hotelList[i].location, kgreyDark, 15.0)
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Container(
                              width: 50.0,
                              decoration: BoxDecoration(
                                color: korange,
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  Icon(
                                    Icons.star,
                                    color: kwhite,
                                    size: 15.0,
                                  ),
                                  BoldText("4.5", 15.0, kwhite)
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            NormalText("(1024 Reviews)", kgreyDark, 11.0),
                          ],
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        BoldText("Book& Save 30% !", 14.0, Colors.red),
                        SizedBox(height: 14),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            SizedBox(
                              width: 90,
                            ),
                            BoldText("More", 12.0, kblack),
                            Icon(
                              Icons.navigate_next,
                              size: 15.0,
                            ),
                          ],
                        )
    ],
  )
],
        ),
      ),
    );

                    },

                    
                   
                  ),
                );
  }
}
