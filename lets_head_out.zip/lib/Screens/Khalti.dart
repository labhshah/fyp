import 'package:flutter/material.dart';
import 'package:flutter_khalti/flutter_khalti.dart';
import 'package:get/get.dart';
import 'package:lets_head_out/utils/booking.dart';

khaltiScreen(BuildContext context,{Hotel hotel}){
  FlutterKhalti _flutterKhalti=FlutterKhalti.configure(
    publicKey: "", 
    urlSchemeIOS: "KhaltiPayFlutterExampleSchema");
    KhaltiProduct product=KhaltiProduct(
      id: "test",
      amount: 8000,
      name: "Payment for hotel",
    );
    _flutterKhalti.startPayment(
      product: product,
      onSuccess: (data)async {
         try {
                     await BookingList.addBookingList(hotel);
                     Get.back();
                   }catch (e) {
                         print(e);
                   }
        print("success");
      },
      onFaliure: (error){
        print(error);
      }
    );
}