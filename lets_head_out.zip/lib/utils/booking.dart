import 'package:cloud_firestore/cloud_firestore.dart';
class Hotel{
  String hotelName,price,location,imageUrl;
  Hotel({this.price="800.00",this.hotelName,this.location,this.imageUrl});
}
List<Hotel>hotelList=[
  Hotel(imageUrl: "moonlight.jpg",hotelName: "MoonLight",location: "Kathmandu"),
  Hotel(imageUrl:"shaara.jpg",hotelName: "Shaara",location: "Pokhara" ),
  Hotel(imageUrl: "yaatrih.jpg",hotelName: "Yaatri",location: "Kathmandu"),
  Hotel(imageUrl: "rupakot.jpg",hotelName: "RupaKot",location: "Pokhara"),
  Hotel(imageUrl: "harrison.jpg",hotelName: "Harrison Palace",location: "Biratnagar"),
  
];
class BookingList{

  static FirebaseFirestore _firebaseFirestore =FirebaseFirestore.instance;
  static Future<DocumentReference> addBookingList(Hotel hotel){
    CollectionReference _hotelReference = _firebaseFirestore.collection("bookingList");
    var data={
      'hotelName':hotel.hotelName,
      "location":hotel.location,
      "price":hotel.price
    };
    print("done");
    return _hotelReference.add(data);
  }

}